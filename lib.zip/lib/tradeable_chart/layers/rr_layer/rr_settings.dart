class RRSettings {}
